package com.sheryians.major;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * MajorApplicationTests contains tests for the MajorApplication class.
 */
@SpringBootTest
class MajorApplicationTests {

    /**
     * Tests if the application context loads successfully.
     */
    @Test
    void contextLoads() {
    }
}
